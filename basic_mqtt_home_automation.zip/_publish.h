#include <MqttConnector.h>
#include <Arduino.h>
//extern int relayPinState;
extern MqttConnector* mqtt;

//extern int relayPin;
//extern int LED_PIN;
extern char charArray[];
extern char myName[];
extern void readInputSwitches();
extern void convertInt();
extern int lastButtonState[];
//static void readSensor(); 

extern String DEVICE_NAME;
extern int PUBLISH_EVERY;

// String intArrayToCSV(int arr[], int arrSize);
// String intArrayToCSV(int arr[], int arrSize) {
//   String result = "";

//   for (int i = 0; i < arrSize; i++) {
//     result += String(arr[i]);
//     if (i < arrSize - 1) {
//       result += ",";
//     }
//   }

//   return result;
// }

//int lastButtonState[] = {1, 0, 1, 1, 0};

// Now, charArray contains the comma-separated values as a C-style string
//Serial.println(charArray);
extern String testStr;
extern void readInThenOut();
void register_publish_hooks() {
  strcpy(myName, DEVICE_NAME.c_str());
  mqtt->on_prepare_data_once([&](void) {
    Serial.println("initializing sensor...");
  });

  mqtt->on_before_prepare_data([&](void) {
     readInThenOut();//
   readInputSwitches();// readSensor();
   
  });

//extern void readInThenOut();
  mqtt->on_prepare_data([&](JsonObject *root) {
    JsonObject& data = (*root)["d"];
    JsonObject& info = (*root)["info"];
    data["myName"] = myName;
    data["millis"] = millis();
    //////////////////////
    data["inputSwitches"]=testStr.c_str();//charArray;//"1,1,2,2,2,3,3,";//charArray;//intArrayToCSV(intArray, sizeof(intArray) / sizeof(intArray[0])).c_str();


    ////////////////////
    //data["relayState"] =0;// relayPinState;
    data["updateInterval"] = PUBLISH_EVERY;
  }, PUBLISH_EVERY);
  mqtt->on_after_prepare_data([&](JsonObject * root) {
    /**************
      JsonObject& data = (*root)["d"];
      data.remove("version");
      data.remove("subscription");
    **************/
  });

  mqtt->on_published([&](const MQTT::Publish & pub) {
      Serial.println("Published.");
  });
}

static void readSensor() {
  // perform reading sensor 
  Serial.println("Perform reading sensor...");
}
