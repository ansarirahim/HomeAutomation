#include <Arduino.h> 

/* BOARD INFO */
#define VERSION_REVISION "HOME AUTOMATION VER1 REV1"
String DEVICE_NAME      = "HOME_AUTO"; 

/* WIFI INFO */ 
String WIFI_SSID        = "Airtel_seem_2877";
String WIFI_PASSWORD    = "air44055";

/* MQTT INFO */ 
String MQTT_HOST        = "3.110.187.253";
String MQTT_USERNAME    = "";
String MQTT_PASSWORD    = "";
String MQTT_CLIENT_ID   = "";
String MQTT_PREFIX      = "HA/";

int    MQTT_PORT        = 1883;
int PUBLISH_EVERY       = 5L * 1000;
int MQTT_CONNECT_TIMEOUT= 10;// 

///////////
// Define input pins
#define SW_1 15
#define SW_2 16
#define SW_3 17
#define SW_4 18
#define SW_5 8
#define SW_6 21
#define SW_7 14
#define SW_FAN 3

// Define corresponding output pins without "IO_"
#define B1_SIG 45
#define B2_SIG 35
#define B3_SIG 36
#define B4_SIG 37
#define B5_SIG 38
#define B6_SIG 39
#define B7_SIG 40 

// Define debounce delay in milliseconds
#define DEBOUNCE_DELAY 50
// Define delay times
#define LOW_DELAY 200
#define HIGH_DELAY 200

#define SOURCE_GPIO 0
#define SOURCE_MQTT 1
#define AUTO_MANUAL_SWITCH 33
#define RESOLUTION 12
#define ADC_PIN 2
#define FAN_SIG 46
 #define ZCD 34


