#include <Arduino.h>
#include <MqttConnector.h>

extern MqttConnector* mqtt;

extern String MQTT_CLIENT_ID;
extern String MQTT_PREFIX;
const char* UPDATE_PRESET = "UPDATE_HOME_AUTOMATION_DATA";
//extern int relayPin;
//extern int relayPinState;
extern char myName[];
extern int outputPins[];
#define NO_OF_SUB_DATA 3
unsigned int presetThc[NO_OF_SUB_DATA];
bool  mqttPresetUpdateCommand=false;
#define MQTT_SUB_SWITCH_INDEX 0
#define MQTT_SUB_SPEED_INDEX 1
#define MQTT_SUB_AUTO_INDEX 2
void parseAndUpdatePreset(const char* input) {
  char keyword[strlen(UPDATE_PRESET) + 1];
  Serial.printf("\nOK-MQTT_Sub=%s", input);
  
  // Extract keyword and numeric values
  int bytesRead = sscanf(input, "%[^=]=%u,%u,%u", keyword, &presetThc[MQTT_SUB_SWITCH_INDEX], &presetThc[MQTT_SUB_SPEED_INDEX], &presetThc[MQTT_SUB_AUTO_INDEX]);

  if (bytesRead >= NO_OF_SUB_DATA && strcmp(keyword, UPDATE_PRESET) == 0) {
    // Keyword matches and values are successfully read
    Serial.print("Keyword matched: ");
    Serial.println(UPDATE_PRESET);
    Serial.print("MQTT_SWITCH_UPDATE: ");
    Serial.println(presetThc[MQTT_SUB_SWITCH_INDEX]);
    Serial.print("MQTT_SPEED_UPDATE: ");
    Serial.println(presetThc[MQTT_SUB_SPEED_INDEX]);
    Serial.print("MQTT_AUTO_MANUAL_UPDATE: ");
    Serial.println(presetThc[MQTT_SUB_AUTO_INDEX]);
    
    // Test and control GPIO pins based on the 8 bits of presetThc[MQTT_SUB_SWITCH_INDEX]
    for (int bitIndex = 0; bitIndex < 7; bitIndex++) {
      bool isBitSet = (presetThc[MQTT_SUB_SWITCH_INDEX] & (1 << bitIndex)) != 0;
      
      // Use outputPins[bitIndex] directly in digitalWrite
      digitalWrite(outputPins[bitIndex], isBitSet ? HIGH : LOW);
    }
    
    // Continue with other actions or updates as needed
    // updateBuffers();
    mqttPresetUpdateCommand = true;
  } else {
    // Keyword doesn't match or incorrect format
    Serial.println("Invalid input format or keyword");
  }
}

// void parseAndUpdatePreset(const char* input) {
//   char keyword[strlen(UPDATE_PRESET) + 1];
//   //int num1, num2, num3;
//   Serial.printf("\nOK-MQTT_Sub=%s", input);
//   // Extract keyword and numeric values
//   int bytesRead = sscanf(input, "%[^=]=%u,%u,%u", keyword, &presetThc[MQTT_SUB_SWITCH_INDEX], &presetThc[MQTT_SUB_SPEED_INDEX], &presetThc[MQTT_SUB_AUTO_INDEX]);

//   if (bytesRead >=NO_OF_SUB_DATA && strcmp(keyword, UPDATE_PRESET) == 0) {
//     // Keyword matches and values are successfully read
//     // Now you can use num1, num2, and num3 for further processing
//     Serial.print("Keyword matched: ");
//     Serial.println(UPDATE_PRESET);
//   Serial.print("MQTT_SWITCH_UPDATE: ");
//     Serial.println(presetThc[MQTT_SUB_SWITCH_INDEX]);
//     Serial.print("MQTT_SPEED_UPDATE: ");
//     Serial.println(presetThc[MQTT_SUB_SPEED_INDEX]);
//     Serial.print("MQTT_AUTO_MANUAL_UPDATE: ");
//     Serial.println(presetThc[MQTT_SUB_AUTO_INDEX]);
//     //updateBuffers();  //
//     mqttPresetUpdateCommand = true;

//     // Perform actions based on the extracted values
//     // For example, update presets or perform some other operations
//   } else {
//     // Keyword doesn't match or incorrect format
//     Serial.println("Invalid input format or keyword");
//   }
// }
//extern int LED_PIN;

// void register_receive_hooks() {
//   mqtt->on_subscribe([&](MQTT::Subscribe *sub) -> void {
//     Serial.printf("myName = %s \r\n", myName);
//     sub->add_topic(MQTT_PREFIX + myName + "/$/+");
//     sub->add_topic(MQTT_PREFIX + MQTT_CLIENT_ID + "/$/+");
//   });
void register_receive_hooks() {
  mqtt->on_subscribe([&](MQTT::Subscribe* sub) -> void {
    ///Serial.printf("Environment Data = %s \r\n", Environment_Data);
    sub->add_topic(MQTT_PREFIX+ myName + "/$/+");
    sub->add_topic(MQTT_PREFIX + MQTT_CLIENT_ID + "/$/+");
  });

  mqtt->on_before_message_arrived_once([&](void) { });

 
 
 
  mqtt->on_message([&](const MQTT::Publish & pub) {
Serial.println("NEWReceived MQTT Message:");
    Serial.printf("NEWTopic: %s\n", pub.topic().c_str());
    Serial.printf("NEWPayload: %s\n", pub.payload_string().c_str());


   });

  mqtt->on_after_message_arrived([&](String topic, String cmd, String payload) {
    Serial.printf("topic: %s\r\n", topic.c_str());
    Serial.printf("cmd: %s\r\n", cmd.c_str());
    Serial.printf("payload: %s\r\n", payload.c_str());
    if (cmd == "$/command") {
      parseAndUpdatePreset(payload.c_str());


      if (payload == "ON") {
 //       digitalWrite(relayPin, HIGH);
  //      digitalWrite(LED_PIN, LOW);
    //    relayPinState = HIGH;
      }
      else if (payload == "OFF") {
    //    digitalWrite(relayPin, LOW);
     //   digitalWrite(LED_PIN, HIGH);
     //   relayPinState = LOW;
      }
    }
    else if (cmd == "$/reboot") {
      ESP.restart();
    }
    else {
      // another message.
    }
  });
}
